<?php

namespace App\Http\Controllers\Api\Vi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LogoutController extends Controller
{
    //
}
